
const BASE_URL = 'http://localhost:4000';

export const getSimulados = async () => {
  const res = await fetch(`${BASE_URL}/simulados`);
  return res.json();
};

export const getQuestoesSimulado = async (id) => {
  const res = await fetch(`${BASE_URL}/simulados/${id}`);
  return res.json();
};

export const corrigirSimulado = async (respostas) => {
  const res = await fetch(`${BASE_URL}/corrigir`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(respostas)
  });
  return res.json();
};
