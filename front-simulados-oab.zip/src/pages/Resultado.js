
import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Resultado({ resultado, setSimulado, setResultado }) {
  const navigate = useNavigate();

  const handleVoltar = () => {
    setSimulado(null);
    setResultado(null);
    navigate('/');
  };

  if (!resultado) return <p>Nenhum resultado disponível.</p>;

  return (
    <div>
      <h2>Resultado</h2>
      <p>Acertos: {resultado.acertos}</p>
      <p>Erros: {resultado.erros.length}</p>
      <p>Diagnóstico: {resultado.diagnostico}</p>
      <p>Plano de Estudos: {resultado.analiseSimulado}</p>

      <h3>Questões Erradas:</h3>
      <ul>
        {resultado.erros.map((erro) => (
          <li key={erro.questao_id}>
            Questão {erro.questao_id} — Resposta marcada: {erro.resposta_usuario}, Correta: {erro.resposta_correta}
          </li>
        ))}
      </ul>

      <button onClick={handleVoltar}>Voltar à Lista</button>
    </div>
  );
}
