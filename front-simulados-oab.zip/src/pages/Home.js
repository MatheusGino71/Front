
import React, { useEffect, useState } from 'react';
import { getSimulados } from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function Home({ setSimulado }) {
  const [simulados, setSimulados] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    getSimulados().then(data => setSimulados(data.simulados));
  }, []);

  const handleSelecionar = (simulado) => {
    setSimulado(simulado);
    navigate('/simulado');
  };

  return (
    <div>
      <h2>Escolha um Simulado</h2>
      {simulados.map(simulado => (
        <button key={simulado.id} onClick={() => handleSelecionar(simulado)}>
          {simulado.nome}
        </button>
      ))}
    </div>
  );
}
