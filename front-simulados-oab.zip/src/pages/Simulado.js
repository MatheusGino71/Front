
import React, { useEffect, useState } from 'react';
import { getQuestoesSimulado, corrigirSimulado } from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function Simulado({ simulado, setResultado }) {
  const [questoes, setQuestoes] = useState([]);
  const [respostas, setRespostas] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    if (simulado) {
      getQuestoesSimulado(simulado.id).then(data => setQuestoes(data.questoes));
    }
  }, [simulado]);

  const handleChange = (questaoId, alternativa) => {
    setRespostas(prev => ({ ...prev, [questaoId]: alternativa }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = Object.entries(respostas).map(([questao_id, resposta_usuario]) => ({
      questao_id,
      resposta_usuario
    }));

    const resultado = await corrigirSimulado(payload);
    setResultado(resultado);
    navigate('/resultado');
  };

  if (!simulado) return <p>Nenhum simulado selecionado.</p>;

  return (
    <form onSubmit={handleSubmit}>
      <h2>{simulado.nome}</h2>
      {questoes.map(q => (
        <div key={q.id}>
          <p>{q.enunciado}</p>
          {q.alternativas.map(a => (
            <label key={a}>
              <input
                type="radio"
                name={`questao-${q.id}`}
                value={a}
                checked={respostas[q.id] === a}
                onChange={() => handleChange(q.id, a)}
              />
              {a}
            </label>
          ))}
        </div>
      ))}
      <button type="submit">Enviar Respostas</button>
    </form>
  );
}
