
import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Simulado from './pages/Simulado';
import Resultado from './pages/Resultado';

function App() {
  const [simulado, setSimulado] = useState(null);
  const [resultado, setResultado] = useState(null);

  return (
    <div className="App">
      <h1>Simulados OAB</h1>
      <Routes>
        <Route path="/" element={<Home setSimulado={setSimulado} />} />
        <Route path="/simulado" element={<Simulado simulado={simulado} setResultado={setResultado} />} />
        <Route path="/resultado" element={<Resultado resultado={resultado} setSimulado={setSimulado} setResultado={setResultado} />} />
      </Routes>
    </div>
  );
}

export default App;
